---
name: Cinematic High-End Media System
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#e8bcb9'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#af8785'
  outline-variant: '#5e3f3d'
  surface-tint: '#ffb3af'
  primary: '#ffb3af'
  on-primary: '#68000e'
  primary-container: '#e8002d'
  on-primary-container: '#fffaf9'
  inverse-primary: '#bf0023'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b4b4'
  tertiary: '#c8c6c5'
  on-tertiary: '#303030'
  tertiary-container: '#747373'
  on-tertiary-container: '#fdfaf9'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3af'
  on-primary-fixed: '#410006'
  on-primary-fixed-variant: '#930018'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  h1:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  h2:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.03em
  h3:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-page: 48px
  stack-xs: 4px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The design system is engineered to evoke the immersive, high-stakes atmosphere of a modern cinema. The brand personality is premium, authoritative, and energetic, focusing on the content as the hero. It targets enthusiasts who demand a sophisticated environment for media discovery and tracking.

The design style is a hybrid of **Minimalism** and **Glassmorphism**. By using deep, light-absorbing backgrounds and translucent surface layers, the interface achieves a sense of physical depth. High-quality imagery is prioritized, allowing movie posters and backdrops to define the visual mood while the UI provides a structured, high-contrast framework.

## Colors

This design system utilizes an "ink-pool" approach to darkness. The primary color—a vibrant, energetic red—is used sparingly but with high impact for critical calls to action, branding, and active states, mimicking the glow of a "Record" light or theater signage.

The background hierarchy uses `#0f0f0f` for the lowest level (base), while `#181818` and `#222222` provide structural definition for navigation and container elements. Secondary text is significantly de-emphasized in muted grays to ensure the user's eye is always drawn first to high-quality media assets and primary titles.

## Typography

The typography strategy focuses on a "Movie Poster" aesthetic. Headlines are set with heavy weights and tight letter-spacing to create a dense, impactful visual block. **Inter** is the typeface of choice for its technical precision and readability against dark backgrounds.

Body text maintains a generous line height (1.6) to prevent eye fatigue during long reading sessions, such as episode synopses or reviews. Labels and metadata use uppercase styling with increased letter spacing to provide a clear functional distinction from narrative content.

## Layout & Spacing

The design system employs a **Fixed Grid** model for desktop, centered on a 1440px maximum container to maintain the cinematic aspect ratio of the content. A 12-column grid is used to organize media cards, typically spanning 2 or 3 columns each.

The spacing rhythm is based on a strict 8px incremental scale. Generous page margins (48px) ensure that content feels "framed" rather than cramped. Vertical stacking follows a clear hierarchy: 12px for internal component spacing and 24px-48px for section separation.

## Elevation & Depth

Depth is achieved through **Glassmorphism** and **Tonal Layers** rather than traditional drop shadows. As elements "rise" in the hierarchy, they become lighter in color and more translucent.

- **Level 0 (Base):** Deep black (#0f0f0f).
- **Level 1 (Cards/Sidebar):** Dark charcoal (#181818) with a 1px subtle border (#2a2a2a).
- **Level 2 (Modals/Overlays):** Glassmorphic surfaces with a 20px-40px background blur, a slight white tint (5-10% opacity), and a thin light-gray stroke.

Interactive states should utilize "inner glows" in the primary red to simulate backlighting rather than external shadows.

## Shapes

The design system uses a **Rounded** shape language to soften the high-contrast dark theme. A base radius of 8px (0.5rem) is applied to buttons and small inputs, while larger media posters and cards utilize 12px or 16px (rounded-lg/xl) to create a modern, friendly feel.

Circular shapes are reserved exclusively for avatars and specific iconography (like play buttons) to create immediate visual recognition of actionable media controls.

## Components

### Buttons
Primary buttons use a solid Red (#e8002d) fill with white text, featuring a subtle gradient from top to bottom. Secondary buttons use a glassmorphic style: a semi-transparent gray fill with a thin border. All buttons should have a 200ms transition on hover, slightly increasing in brightness or scale.

### Media Cards
Posters are the core component. They feature a 12px corner radius and a subtle inner stroke to define edges against the black background. On hover, cards should slightly scale up (1.05x) and reveal a semi-transparent overlay with quick-action icons (e.g., "Add to Watchlist").

### Progress Bars
Used for tracking watch progress. These consist of a dark background track (#2a2a2a) and a vibrant red (#e8002d) fill. For a high-end feel, the red fill can include a faint "pulse" animation for active media.

### Input Fields
Search bars and text inputs utilize the #181818 surface color with a 1px border. Upon focus, the border transitions to the primary red, and the background blur increases to pull the input forward.

### Chips & Badges
Small, pill-shaped indicators for genres or status (e.g., "4K", "Trending"). These use a low-contrast background (#2a2a2a) with uppercase label typography to remain secondary to the main titles.